<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'qB=LL!LM=|zEW#dHxQ[G&?psE]S=LS-*oAu1^~Rwb.%::XM<JW9J;F34uHATESdk' );
define( 'SECURE_AUTH_KEY',   '^Jz3>zi|9_B[@hf4uyh?T#sT)sWZBz)?VEXtUsk5j/{fE?MF>6SksKA5XPE.m_Xt' );
define( 'LOGGED_IN_KEY',     'e3sZut=wA[Ke!.VulM&5w1G?WUM@[-nA*lPK!+Sa0-JZrJ4e7p,1f!CJeXtd0x!A' );
define( 'NONCE_KEY',         ')JsEm*Ltqfj[ux5`f:?Z%fc!sQbspB56n@*R;B2C7&(g~XH:v;4yzojO6J]4Bo7c' );
define( 'AUTH_SALT',         '$q~Ui6s*IM]I()9DGQmM5/H;2x|%?W_$<vSGYhrmB/aDlP~#|kaJJhAFV]:2FXQ/' );
define( 'SECURE_AUTH_SALT',  'I3/zf+A-K]6GGlO,Tdd[XH;*@o^[X0PywUdew<N]hr54*h}=hWH.=cwZxV>r5ls7' );
define( 'LOGGED_IN_SALT',    'p~U{AFrNvt8&(`/&H(c`9  QOcF?!qo (&5jKvJ?L#`&+-2WCeC2JOXJ5LpejZI@' );
define( 'NONCE_SALT',        'ACo:GBU8/l6==BgTYEek:^rvZsmKcX;2@/3;-V,y4oc:AssWUxL7=gdW)X9nR,_2' );
define( 'WP_CACHE_KEY_SALT', 'L,XR/xu-u{;S[hlc5Da@_~rS^GTVXP8gA)iYB#>r.cYx$Uzmw&bD1Nd84:YV@<K2' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
